def function_1():
    print('Hello, world!')


def function_2():
    print('Hello, world')
